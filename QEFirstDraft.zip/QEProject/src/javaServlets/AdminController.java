package javaServlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Objects;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaDAO.BrandsDAO;
import javaDAO.CategoryDAO;
import javaDAO.ItemsDAO;
import javaModels.Brand;
import javaModels.Category;
import javaModels.Items;

/* This servlet is set to respond to requests with the URL pattern "/HomeServlet or 
 * "/HomeServlet followed by a slash and zero or more characters. */
@WebServlet({"/AdminController", "/AdminController/*"})
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		/* The action string will be assigned the URL route and determine which 
		 * servlet method gets called by using a switch block. */
		String action = null;
		String servletPath = request.getServletPath();
		String pathInfo = request.getPathInfo();
		
		/* If there are no characters after the servlet path (pathInfo will be 
		 * null) or if the servlet path is followed by a single "/" then the action 
		 * string will be assigned only the servlet path. If there is a slash 
		 * followed by any characters, then the action string will be assigned the 
		 * servlet path plus the additional path information. */
		if (pathInfo == null || pathInfo.equals("/")) {
			action = servletPath;
		} else {
			action = servletPath + pathInfo;
		}
		// Verify the action string by printing to the console
		System.out.println(action);
		
		try
		{
			switch(action) {
				case "/AdminController":
					showAdminPage(request, response);
					break;
				case "/AdminController/showAddItem":
				try {
					showAddItem(request, response);
				} catch (SQLException e) {
					System.out.println("Unable to send Categories or brands");
					e.printStackTrace();
				}
					break;
				case "/AdminController/showRemoveItem":
				try {
					showRemoveItem(request, response);
				} catch (SQLException e) {
					System.out.println("Unable to send Items");
					e.printStackTrace();
				}
					break;
				case "/AdminController/showAddCategory":
					showAddCategory(request, response);
					break;
				case "/AdminController/showRemoveCategory":
					showRemoveCategory(request, response);
					break;
				case "/AdminController/showAddBrand":
					showAddBrand(request, response);
					break;
				case "/AdminController/showRemoveBrand":
					showRemoveBrand(request, response);
					break;
				case "/AdminController/verifyAddItem":
					verifyAddItem(request, response);
					break;
				case "/AdminController/verifyRemoveItem":
					verifyRemoveItem(request, response);
					break;
				case "/AdminController/verifyAddCategory":
					verifyAddCategory(request, response);
					break;
				case "/AdminController/verifyRemoveCategory":
					verifyRemoveCategory(request, response);
					break;
				case "/AdminController/verifyAddBrand":
					verifyAddBrand(request, response);
					break;
				case "/AdminController/verifyRemoveBrand":
					verifyRemoveBrand(request, response);
					break;
				default:
					showAdminPage(request, response);
					break;
			}
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void showAdminPage(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/adminPage.jsp");
		rd.forward(request, response);
	}
	
	private void showAddItem(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException, SQLException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/addItem.jsp");
		
		CategoryDAO c_dao = new CategoryDAO();
		
		BrandsDAO b_dao = new BrandsDAO();
		
		ArrayList<Category> allCategories = c_dao.getAllCategory();
		
		ArrayList<Brand> allBrands = b_dao.getAllBrands();
		
		request.setAttribute("allCategories", allCategories);
		
		request.setAttribute("allBrands", allBrands);
		
		request.setAttribute("error", "");
		
		rd.forward(request, response);
	}
	
	private void showRemoveItem(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException, SQLException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/removeItem.jsp");
		
		ItemsDAO i_dao = new ItemsDAO();
		
		ArrayList<Items> allItems = i_dao.getAllItems();
		
		request.setAttribute("allItems", allItems);
		
		request.setAttribute("error", "");
		
		rd.forward(request, response);
	}
	
	private void showAddCategory(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/addCategory.jsp");
				
		request.setAttribute("error", "");
		
		rd.forward(request, response);
	}
	
	private void showRemoveCategory(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/removeCategory.jsp");
		
		request.setAttribute("error", "");
		
		CategoryDAO c_dao = new CategoryDAO();
		
		try {
			
			ArrayList<Category> allCategory = c_dao.getAllCategory();
			
			request.setAttribute("allCategory", allCategory);
			
		}catch(Exception e) {
			
			System.out.println("Unable to retrieve categories to show");
			
		}
		
		rd.forward(request, response);
	}
	
	private void showAddBrand(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/addBrand.jsp");
		
		request.setAttribute("error", "");
		
		rd.forward(request, response);
	}
	
	private void showRemoveBrand(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/removeBrand.jsp");
		
		request.setAttribute("error", "");
		
		BrandsDAO b_dao = new BrandsDAO();
		
		try {
			
			ArrayList<Brand> allBrands = b_dao.getAllBrands();
			
			request.setAttribute("allBrands", allBrands);
			
		}catch(Exception e) {
			
			System.out.println("Unable to retrieve brands to show");
			
		}
		
		rd.forward(request, response);
	}
	
	private void verifyAddItem(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/addItem.jsp");
		
		String itemName = request.getParameter("itemDesc");
		System.out.println(itemName);
		
		Double itemPrice = Double.parseDouble(request.getParameter("itemPrice"));
		System.out.println(itemPrice);
		
		Integer categoryId = Integer.parseInt(request.getParameter("categoryOption"));
		System.out.println(categoryId);
		
		Integer brandId = Integer.parseInt(request.getParameter("brandOption"));
		System.out.println(brandId);
	
		ItemsDAO i_dao = new ItemsDAO();
		
		try {
			
			if(itemName.equals("")||Objects.isNull(itemName)) {
				throw new java.sql.SQLException();
			}
			
			i_dao.registerItemExcludeId(new Items(1,categoryId,brandId,itemPrice,itemName,true));
			
			CategoryDAO c_dao = new CategoryDAO();
			
			BrandsDAO b_dao = new BrandsDAO();
			
			ArrayList<Category> allCategories = c_dao.getAllCategory();
			
			ArrayList<Brand> allBrands = b_dao.getAllBrands();
			
			request.setAttribute("allCategories", allCategories);
			
			request.setAttribute("allBrands", allBrands);
			
			request.setAttribute("error", "Succefully added item");
			
			
		}catch(Exception e) {
			
			rd = request.getRequestDispatcher("/WEB-INF/adminViews/addItem.jsp");
			request.setAttribute("error", "Unable to insert item. Check fields");
			
			CategoryDAO c_dao = new CategoryDAO();
			
			BrandsDAO b_dao = new BrandsDAO();
			
			try {
			ArrayList<Category> allCategories = c_dao.getAllCategory();
			
			ArrayList<Brand> allBrands = b_dao.getAllBrands();
			
			request.setAttribute("allCategories", allCategories);
			
			request.setAttribute("allBrands", allBrands);
			
			}catch(Exception f) {
				System.out.println("Unable to reload addItems Page properly");
			}
			
			System.out.println("Unable to add new Item");
		}
		
		rd.forward(request, response);
	}
	
	private void verifyRemoveItem(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/removeItem.jsp");
		
		Integer itemID = Integer.parseInt(request.getParameter("id"));
		
		ItemsDAO i_dao = new ItemsDAO();
		
		try {
			
			i_dao.removeItemById(itemID);
			
			ArrayList<Items> allItems = i_dao.getAllItems();

			request.setAttribute("allItems", allItems);
			request.setAttribute("error", "Successfully removed item!");
			
		}catch(Exception e) {
			
			ArrayList<Items> allItems;
			try {
				allItems = i_dao.getAllItems();

				request.setAttribute("allItems", allItems);
				
				request.setAttribute("error", "Unable to remove item");
				
				System.out.println("Unable to remove Item");
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
			
		}
		
		rd.forward(request, response);
	}

	private void verifyAddCategory(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/addCategory.jsp");
		
		String categoryName = request.getParameter("categoryName");
			
		String categoryDescription = request.getParameter("categoryDescription");
		
		CategoryDAO c_dao = new CategoryDAO();
		
		try {
			System.out.println("Registered new category");
			
			request.setAttribute("error", "Succesfully added category");
			
			if(categoryName.equals("")||Objects.isNull(categoryName)) {
			    throw new java.sql.SQLException();
			}
			
			c_dao.registerCategory(new Category(1,categoryName,categoryDescription));
			
			
		}catch(Exception e) {
			
			System.out.println("Unable to add Category");
			
			request.setAttribute("error", "Unable to add category. Make sure fields are not empty");
			
		}
		
		rd.forward(request, response);
	}
	
	private void verifyRemoveCategory(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/removeCategory.jsp");
		
		Integer categoryId = Integer.parseInt(request.getParameter("id"));
		
		CategoryDAO c_dao = new CategoryDAO();
		
		try {
			
			c_dao.removeCategoryById(categoryId);
			System.out.println("Removed category");
			
			request.setAttribute("error", "Successfully removed category");
			
			ArrayList<Category> allCategory = c_dao.getAllCategory();
			
			request.setAttribute("allCategory", allCategory);
			
		}catch(Exception e) {
			
			System.out.println("Unable to remove category. Check whether there are not items with this category");
			
			request.setAttribute("error", "Unable to remove category. Check whether there are no items with this category "
					+ "before removing it.");
			
			try {
				
				ArrayList<Category> allCategory = c_dao.getAllCategory();
				
				request.setAttribute("allCategory", allCategory);
				
			}catch(Exception f) {
				System.out.println("Unable to reload remove category page");
			}
			
		}
		
		
		
		rd.forward(request, response);
	}

	private void verifyAddBrand(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/addBrand.jsp");
		
		String brandName = request.getParameter("brandName");
			
		String brandDescription = request.getParameter("brandDescription");
		
		BrandsDAO b_dao = new BrandsDAO();
		
		try {
			System.out.println("Registered new brand");
			
			request.setAttribute("error", "Succesfully added brand");
			
			if(brandName.equals("")||Objects.isNull(brandName)) {
			    throw new java.sql.SQLException();
			}
			
			b_dao.registerBrandExcludeId(new Brand(1,brandName,brandDescription));
			
			
		}catch(Exception e) {
			
			System.out.println("Unable to add Brand");
			
			request.setAttribute("error", "Unable to add brand. Make sure fields are not empty");
			
		}
		
		rd.forward(request, response);
	}

	private void verifyRemoveBrand(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/adminViews/removeBrand.jsp");
		
		Integer brandId = Integer.parseInt(request.getParameter("id"));
		
		BrandsDAO b_dao = new BrandsDAO();
		
		try {
			
			b_dao.removeBrandById(brandId);
			System.out.println("Removed brand");
			
			request.setAttribute("error", "Successfully removed brand");
			
			ArrayList<Brand> allBrands = b_dao.getAllBrands();
			
			request.setAttribute("allBrands", allBrands);
			
		}catch(Exception e) {
			
			System.out.println("Unable to remove brand. Check whether there are not items with this brand");
			
			request.setAttribute("error", "Unable to remove brand. Check whether there are no items with this brand "
					+ "before removing it.");
			
			try {
				
				ArrayList<Brand> allBrands = b_dao.getAllBrands();
				
				request.setAttribute("allBrands", allBrands);
				
			}catch(Exception f) {
				System.out.println("Unable to reload remove brand page");
			}
			
		}
		
		
		
		rd.forward(request, response);
	}
}